# Geeknote plugin

This plugin provides autocompletion for [Geeknote](https://github.com/VitaliyRodnenko/geeknote)
and an alias for `geeknote` called `gn`.

To use it, add `geeknote` to the plugins array in your zshrc file:

```zsh
plugins=( ... geeknote ...)
```
